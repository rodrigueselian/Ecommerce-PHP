<button id="login">Login</button>
                <div id="loginpop">
                <button id="x">x</button>
                    <form class="logcontainer" method="post">
                        Email:
                        <input type="text" name="login" placeholder="Seu Email" Required>
                        Senha:
                        <input type="password" name="senha" placeholder="Sua Senha" Required>
                        <input type="submit" name="reqlogin" value="login">
                    </form>
                </div>
            <button id="register">Register</button>
                <div id="registerpop">
                <button id="x2">x</button>
                    <form class="logcontainer" method="post">
                        Nome:
                        <input type="text" name="nome" placeholder="Seu Nome" Required>
                        Email:
                        <input type="text" name="login" placeholder="Seu Email" Required>
                        Senha:
                        <input type="password" name="senha" placeholder="Sua Senha" Required>
                        <input type="submit" name="reqlogin" value="register">
                    </form>
                </div>
<?php

?>