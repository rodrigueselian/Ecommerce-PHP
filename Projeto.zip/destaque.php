<div class="destaque">
    <img src=<?=$destaque['img']?>>
    <h2><?=$destaque['pronome']?></h2>
    <p>$<?=$destaque['propreco']?></p>
    <button>Add to Cart</button>
</div>