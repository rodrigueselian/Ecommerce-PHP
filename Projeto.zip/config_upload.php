<?php
//parâmetros de configuração para o upload

// limitar as extensões? (sim ou não)
$limitar_ext="sim";

//extensões autorizadas
$extensoes_validas=array(".gif",".jpg",".jpeg",".bmp",".GIF",".JPG",".JPEG",".BMP",);

// caminho absoluto onde os arquivos serão armazenados
$caminho="/uploads";

// limitar o tamanho do arquivo? (sim ou não)
$limitar_tamanho="sim";

//tamanho limite do arquivo em bytes
$tamanho_bytes="5000000";

// se já existir o arquivo indica se ele deve ser sobrescrito (sim ou não)
$sobrescrever="sim";
?>
