O QUE TU PRECISA SABER ALEM DO QUE TU VIU EM AULA:
-crud pra adicionar categs e produtos foram feitos da maneira tradicional
-o add to cart dos produtos realmente adiciona os produtos pro carrinho (clica no iconezinho vermelho)
-login do admin é "admin@admin.com"
-senha é "senha"
-alem disso tudo, deve ter alguns problemas com resoluções por não ser tão responsivo (eu usei 1440x900 ficou bonitão)


tentei misturar javascript com php não deu muito certo :(
depois que eu notei que tinha muita coisa que devia ser otimizada, me desmotivei e deixei assim.
se conseguir me avaliar com 6.2 pra eu ficar com 8 na media eu vou ficar feliz pra caralho, vlw por tudo prof.
