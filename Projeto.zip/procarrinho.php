<div class="prodDest">
    <img src="<?=$pcar['img']?>">
    <h1><?=$pcar['pronome']?></h1>
    <p><?=$pcar['propreco']?></p>
    <button>X</button>
</div>